package com.jt.liteflow.core.nodeDefinition;

import com.jt.liteflow.core.enums.NodeEnum;
import lombok.NonNull;

public class CommonNode extends Node {

    public CommonNode(@NonNull String id, @NonNull String name) {
        super(id, name, NodeEnum.COMMON);
    }
}
