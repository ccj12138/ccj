package com.jt.liteflow.node;

import com.yomahub.liteflow.core.NodeIfComponent;
import org.springframework.stereotype.Component;

/**
 * @Author: jiangtao
 * @Date 2024/4/2 19:46
 * @Description:
 */
@Component
public class N extends NodeIfComponent {

    @Override
    public boolean processIf() throws Exception {
        System.out.println("执行n节点");
        return true;
    }
}
