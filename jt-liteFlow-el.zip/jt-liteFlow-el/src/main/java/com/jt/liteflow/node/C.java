package com.jt.liteflow.node;

import com.yomahub.liteflow.core.NodeIfComponent;
import org.springframework.stereotype.Component;

/**
 * @Author: jiangtao
 * @Date 2024/4/2 19:46
 * @Description:
 */
@Component
public class C extends NodeIfComponent {

    @Override
    public boolean processIf() throws Exception {
        System.out.println("执行c节点");
        return true;
    }
}
