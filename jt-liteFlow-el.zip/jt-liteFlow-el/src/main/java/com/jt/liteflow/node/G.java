package com.jt.liteflow.node;

import com.yomahub.liteflow.core.NodeSwitchComponent;
import org.springframework.stereotype.Component;

/**
 * @Author: jiangtao
 * @Date 2024/4/2 19:46
 * @Description:
 */
@Component
public class G extends NodeSwitchComponent {

    @Override
    public String processSwitch() throws Exception {
        return null;
    }
}
