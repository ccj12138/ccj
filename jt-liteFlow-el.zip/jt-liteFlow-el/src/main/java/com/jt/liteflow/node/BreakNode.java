package com.jt.liteflow.node;

import com.yomahub.liteflow.core.NodeBreakComponent;
import org.springframework.stereotype.Component;


@Component
public class BreakNode extends NodeBreakComponent {
    @Override
    public boolean processBreak() throws Exception {
        return false;
    }
}
