package com.jt.liteflow.node;

import com.yomahub.liteflow.core.NodeForComponent;
import org.springframework.stereotype.Component;

@Component
public class ForNode extends NodeForComponent {

    @Override
    public int processFor() throws Exception {
        return 0;
    }
}
