package com.jt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author: jiangtao
 * @Date ${DATE} ${TIME}
 * @Description:
 */
@SpringBootApplication
public class LiteFlowApplication {
    public static void main(String[] args) {
        SpringApplication.run(LiteFlowApplication.class, args);
    }
}